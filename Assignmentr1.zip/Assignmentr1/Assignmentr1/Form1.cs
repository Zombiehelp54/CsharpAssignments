﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Assignmentr1
{
    public partial class Form1 : Form
    {
        String provider;
        String connectionString;
        static DbProviderFactory factory;
        DataTable dt;
        DbDataAdapter ad;
        static DbConnection conn;
        string[] providers = { "MySql", "Sqlite", "Ms Access", "Sql Server"};
        string[] connStrs = { "server=localhost;database=students;uid=root;pwd=rootroot;charset=utf8;" , "data source=students.db" , "provider=microsoft.ace.oledb.12.0; data source=students.accdb", "Server=localhost\\SQLEXPRESS;Database=master;Trusted_Connection=True;" };
        string[] providers2 = { "MySql", "SQLite", "System.Data.OleDb", "System.Data.SqlClient"};
        BindingSource bs = new BindingSource();
        public Form1()
        {
            InitializeComponent();
        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.SelectedIndexChanged -= listBox1_SelectedIndexChanged;
            listBox1.DataSource = providers;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = int.Parse(listBox1.SelectedIndex.ToString());
            provider = providers2[index];
            connectionString = connStrs[index];
            Provider(provider);
            start();

        }
        private void Provider(string name)
        {
           
            dt = new DataTable();
            dt.Columns.Add("Name");
            dt.Columns.Add("Description");
            dt.Columns.Add("InvariantName");
            dt.Columns.Add("AssemblyQualifiedName");
            if (name == "MySql")
            {
               
                dt.Rows.Add("MySql Provider", "Desc", "mysqlClient", "MySql.Data.MySqlClient.MySqlClientFactory, MySql.Data");
                factory = DbProviderFactories.GetFactory(dt.Rows[0]);
            }
            else if (name == "SQLite")
            {
               
                dt.Rows.Add("SQLite Provider", "desc", "System.Data.SQLite", "System.Data.SQLite.SQLiteFactory, System.Data.SQLite");
                factory = DbProviderFactories.GetFactory(dt.Rows[0]);
            }
            else
            {
                factory = DbProviderFactories.GetFactory(name);
            }
        }
        private void start()
        {
            conn = factory.CreateConnection();
            conn.ConnectionString = connectionString;
            ad = factory.CreateDataAdapter();
            ad.SelectCommand = conn.CreateCommand();
            ad.SelectCommand.CommandText = "select * from student;";
            DbCommandBuilder commBuilder = factory.CreateCommandBuilder();
            commBuilder.DataAdapter = ad;
            dt = new DataTable();
            ad.Fill(dt);
            setBindings(dt);
        }
        private void setBindings(DataTable source)
        {
            textBox1.DataBindings.Clear();
            textBox2.DataBindings.Clear();
            textBox3.DataBindings.Clear();
            pictureBox1.DataBindings.Clear();
            bs.DataSource = source;
            bindingNavigator1.BindingSource = bs;
            if (provider == "System.Data.OleDb") // I don't have access so I used the file that was provided. I have created the table in my local machine with different column names 
            {
                textBox1.DataBindings.Add("Text", bs, "sno");
                textBox2.DataBindings.Add("Text", bs, "sname");
                textBox3.DataBindings.Add("Text", bs, "Course");
                pictureBox1.DataBindings.Add("Image", bs, "photo", true);
            } else
            {
                textBox1.DataBindings.Add("Text", bs, "sid");
                textBox2.DataBindings.Add("Text", bs, "sname");
                textBox3.DataBindings.Add("Text", bs, "scourse");
                pictureBox1.DataBindings.Add("Image", bs, "image", true);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image files(*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
            DialogResult s = openFileDialog1.ShowDialog();
            if(s == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ad.Update(dt);
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            ad.Update(dt);
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            ad.Update(dt);

        }
    }
}
